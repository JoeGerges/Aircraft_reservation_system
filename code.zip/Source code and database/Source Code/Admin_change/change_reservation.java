package Admin_change;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import Admin.Admin;
import Client.Client;
import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Font;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.TextField;
import javax.swing.JTable;

public class change_reservation {

	private JFrame frame;
	private JTextField textField;
	private JTextField txtEg;
	private JTextField txtEgYyyymmdd;
	private JTextField textField_1;
	private JTable table;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					change_reservation window = new change_reservation();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public change_reservation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();

		frame.getContentPane().setForeground(Color.WHITE);
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		frame.setBounds(500,500,849,516);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0,55,553,420);
		scrollPane.setBackground(new Color(255, 255, 255));
		scrollPane.setForeground(new Color(0, 0, 0));
		frame.getContentPane().add(scrollPane);
		table = new JTable();
		scrollPane.setViewportView(table);
		
		
		
		textField = new JTextField();
		textField.setBounds(559, 41, 225, 44);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		textField.setText("");
		
		JLabel lblReservationNumber = new JLabel("Reservation number");
		lblReservationNumber.setForeground(new Color(0, 0, 0));
		lblReservationNumber.setFont(new Font("Sitka Small", Font.BOLD, 18));
		lblReservationNumber.setBounds(559, 13, 270, 30);
		frame.getContentPane().add(lblReservationNumber);
		
		txtEg = new JTextField();
		txtEg.setText("\r\n");
		txtEg.setBounds(559, 133, 225, 44);
		frame.getContentPane().add(txtEg);
		txtEg.setColumns(10);
		txtEg.setText("");
		
		txtEgYyyymmdd = new JTextField();
		txtEgYyyymmdd.setBounds(559, 226, 225, 44);
		frame.getContentPane().add(txtEgYyyymmdd);
		txtEgYyyymmdd.setColumns(10);
		txtEgYyyymmdd.setText("");
		
		JLabel lblEnterANew = new JLabel("New time");
		lblEnterANew.setForeground(new Color(0, 0, 0));
		lblEnterANew.setFont(new Font("Sitka Small", Font.BOLD, 18));
		lblEnterANew.setBounds(559, 113, 225, 23);
		frame.getContentPane().add(lblEnterANew);
		
		JLabel lblNewLabel = new JLabel("New date");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Sitka Small", Font.BOLD, 18));
		lblNewLabel.setBounds(559, 198, 225, 30);
		frame.getContentPane().add(lblNewLabel);
		
		Button button = new Button("Submit");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String reservation_number = textField.getText();
				String new_time = txtEg.getText();
				String new_date = txtEgYyyymmdd.getText();
				String gate_number = textField_1.getText();
				String request = "AdminChange/"+reservation_number+"/"+new_time+"/"+new_date+"/"+gate_number+"/";
				Client.send_data_to_server(request);

				change_reservation info = new change_reservation();
				change_reservation.main(null);
				
				frame.dispose();
				
				
				
			}
		});
		button.setForeground(new Color(255, 255, 255));
		button.setBackground(new Color(0, 0, 128));
		button.setBounds(559, 404, 108, 43);
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("Delete");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String reservation_number = textField.getText();
				String request = "AdminDelete/"+reservation_number+"/";
				Client.send_data_to_server(request);
				
				change_reservation info = new change_reservation();
				change_reservation.main(null);
				
				frame.dispose();
			}
		});
		button_1.setForeground(new Color(255, 255, 255));
		button_1.setBackground(new Color(0, 0, 128));
		button_1.setBounds(673, 404, 111, 43);
		frame.getContentPane().add(button_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(559, 324, 225, 44);
		frame.getContentPane().add(textField_1);
		
		JLabel lblNewGateNumber = new JLabel("New gate number");
		lblNewGateNumber.setForeground(new Color(0, 0, 0));
		lblNewGateNumber.setFont(new Font("Sitka Small", Font.BOLD, 18));
		lblNewGateNumber.setBounds(559, 296, 225, 30);
		frame.getContentPane().add(lblNewGateNumber);

		
		Connection conn;
		try {
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/parkings?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
	
    	String query = "Select * from clienthistory";
		PreparedStatement st = conn.prepareStatement(query);
		ResultSet rs = st.executeQuery();
		table.setModel(DbUtils.resultSetToTableModel(rs));
		
		Button button_2 = new Button("Back");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin info = new Admin();
				Admin.main(null);
				frame.dispose();
			}
		});
		button_2.setBackground(new Color(0, 0, 128));
		button_2.setFont(new Font("Sitka Small", Font.PLAIN, 15));
		button_2.setBounds(10, 13, 87, 30);
		frame.getContentPane().add(button_2);
		
		Button button_3 = new Button("Logout");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String request = "Logout/";
				Client.send_data_to_server(request);
				frame.dispose();
			}
		});
		button_3.setBackground(new Color(0, 0, 128));
		button_3.setFont(new Font("Sitka Small", Font.PLAIN, 15));
		button_3.setBounds(107, 13, 87, 30);
		frame.getContentPane().add(button_3);

		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
