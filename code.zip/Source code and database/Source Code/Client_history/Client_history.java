package Client_history;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Client.Client;
import Login_Screen.Login_System;
import Parking_reservation.Parking_reservation;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.awt.event.ActionEvent;
import java.sql.*;
import net.proteanit.sql.*;

public class Client_history {

	private static JFrame frmYourHistory;
	public static JTable table;
	private JButton btnBack;
	private JButton btnLogoit;

	/**
	 * Launch the application.
	 */
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Client_history window = new Client_history();
					window.frmYourHistory.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Client_history() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmYourHistory = new JFrame();
		frmYourHistory.setTitle("Your History");
		frmYourHistory.setBounds(500, 500, 693, 497);
		frmYourHistory.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmYourHistory.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 62, 651, 388);
		frmYourHistory.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnLoadYourHistory = new JButton("Load your history");
		btnLoadYourHistory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String request = "LoadHistory/"+Client.clientID+"/";
				Client.send_data_to_server(request);		
			}
		});
		
		btnLoadYourHistory.setFont(new Font("Sitka Small", Font.PLAIN, 16));
		btnLoadYourHistory.setBounds(233, 27, 201, 25);
		frmYourHistory.getContentPane().add(btnLoadYourHistory);
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmYourHistory.dispose();
				Parking_reservation info = new Parking_reservation();
				Parking_reservation.main(null);
			}
		});
		btnBack.setFont(new Font("Sitka Small", Font.PLAIN, 13));
		btnBack.setBounds(12, 24, 97, 25);
		frmYourHistory.getContentPane().add(btnBack);
		
		btnLogoit = new JButton("Logout");
		btnLogoit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String request = "Logout/";
				Client.send_data_to_server(request);
				frmYourHistory.dispose();
			}
		});
		btnLogoit.setFont(new Font("Sitka Small", Font.PLAIN, 13));
		btnLogoit.setBounds(566, 28, 97, 25);
		frmYourHistory.getContentPane().add(btnLogoit);
	}
}
