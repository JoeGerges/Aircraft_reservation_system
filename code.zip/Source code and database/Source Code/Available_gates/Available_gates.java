package Available_gates;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;

import Client.Client;
import ClientInfo.ClientInfo;
import Login_Screen.Login_System;
import Parking_reservation.Parking_reservation;
import Signup.Signup_Screen;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.JPanel;
import java.awt.Button;
import javax.swing.ImageIcon;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Choice;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.PrintWriter;
import java.awt.event.ActionEvent;
import Client.Client;
import java.awt.Color;
import java.awt.Button;
import javax.swing.JSeparator;
import java.awt.Label;
public class Available_gates {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Available_gates window = new Available_gates();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Available_gates() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(new Color(0, 0, 0));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBackground(new Color(0, 0, 0));
		frame.setBounds(100, 100, 832, 521);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		
		JLabel lblAvailableGates = new JLabel("AVAILABLE GATES");
		lblAvailableGates.setForeground(new Color(255, 255, 255));
		lblAvailableGates.setBackground(new Color(255, 255, 255));
		lblAvailableGates.setFont(new Font("Rockwell Nova Extra Bold", Font.PLAIN, 23));
		lblAvailableGates.setBounds(110, 0, 312, 54);
		frame.getContentPane().add(lblAvailableGates);
		
		Button button = new Button("Gate Number 1");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 1;
				button.setBackground(Color.RED);
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button.setForeground(new Color(0, 0, 0));
		button.setBounds(188, 156, 97, 36);
		frame.getContentPane().add(button);
		button.setBackground(Color.GREEN);

		
		Button button_1 = new Button("Gate Number 2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 2;
				button_1.setBackground(Color.RED);
			//	frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_1.setForeground(new Color(0, 0, 0));
		button_1.setBounds(308, 104, 97, 36);
		frame.getContentPane().add(button_1);
		button_1.setBackground(Color.GREEN);
		
		Button button_2 = new Button("Gate Number 3");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 3;
				button_2.setBackground(Color.RED);
				//frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_2.setForeground(new Color(0, 0, 0));
		button_2.setBounds(457, 122, 97, 36);
		frame.getContentPane().add(button_2);
		button_2.setBackground(Color.GREEN);
		
		Button button_3 = new Button("Gate Number 4");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 4;
				button_3.setBackground(Color.RED);
				//frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_3.setForeground(new Color(0, 0, 0));
		button_3.setBounds(581, 146, 97, 36);
		frame.getContentPane().add(button_3);
		button_3.setBackground(Color.GREEN);
		
		Button button_4 = new Button("Gate Number 5");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 5;
				button_4.setBackground(Color.RED);
			//	frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_4.setForeground(new Color(0, 0, 0));
		button_4.setBounds(696, 201, 97, 36);
		frame.getContentPane().add(button_4);
		button_4.setBackground(Color.GREEN);
		
		Button button_5 = new Button("Gate Number 6");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 6;
				button_5.setBackground(Color.RED);
			//	frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_5.setForeground(new Color(0, 0, 0));
		button_5.setBounds(188, 234, 97, 36);
		frame.getContentPane().add(button_5);
		button_5.setBackground(Color.GREEN);
		
		Button button_6 = new Button("Gate Number 7");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 7;
				button_6.setBackground(Color.RED);
				//frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_6.setForeground(new Color(0, 0, 0));
		button_6.setBounds(254, 313, 97, 36);
		frame.getContentPane().add(button_6);
		button_6.setBackground(Color.GREEN);
		
		Button button_7 = new Button("Gate Number 8");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 8;
				button_7.setBackground(Color.RED);
				//frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_7.setForeground(new Color(0, 0, 0));
		button_7.setBounds(379, 351, 97, 36);
		frame.getContentPane().add(button_7);
		button_7.setBackground(Color.GREEN);
		
		Button button_8 = new Button("Gate Number 9");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 9;
				button_8.setBackground(Color.RED);
				//frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_8.setForeground(new Color(0, 0, 0));
		button_8.setBounds(501, 388, 97, 36);
		frame.getContentPane().add(button_8);
		button_8.setBackground(Color.GREEN);
		
		Button button_9 = new Button("Gate Number 10");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Client.gate_number = 10;
				button_9.setBackground(Color.RED);
			//	frame.dispose();
				String request = "Reserve/"+Client.clientID+"/"+Client.company+"/"+Client.pickedDate+"/"+Client.timeSlot+"/"+Client.gate_number+"/";
				Client.send_data_to_server(request);	
			}
		});
		button_9.setForeground(new Color(0, 0, 0));
		button_9.setBounds(652, 415, 97, 36);
		frame.getContentPane().add(button_9);
		button_9.setBackground(Color.GREEN);
		
		Button button_10 = new Button("Refresh");
		button_10.setBackground(Color.WHITE);
		button_10.setForeground(Color.BLACK);
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				String request = "Refresh/"+Client.timeSlot+"/"+Client.pickedDate+"/";
				Client.send_data_to_server(request);
			}
		});
		button_10.setFont(new Font("Sitka Small", Font.PLAIN, 13));
		button_10.setBounds(622, 13, 79, 36);
		frame.getContentPane().add(button_10);
		
		Button button_11 = new Button("Back");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Reservation.Reservation info = new Reservation.Reservation();
				Reservation.Reservation.main(null);
			}
		});
		button_11.setBackground(Color.WHITE);
		button_11.setForeground(Color.BLACK);
		button_11.setBounds(707, 13, 79, 36);
		frame.getContentPane().add(button_11);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(12, 92, 62, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(12, 0, 790, 461);
		frame.getContentPane().add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon(Login_System.class.getResource("/images/1 (1).jpg")));
		
		for(int i = 0; i<Client.gates_not_available.length; i++)
		{
			if(!Client.gates_not_available[i].equals(""))
			{
				String[] gate_reserved = Client.gates_not_available[i].split(" ");
				if(Integer.parseInt(gate_reserved[2]) == 1)
				{
					button.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 2)
				{
					button_1.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 3)
				{
					button_2.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 4)
				{
					button_3.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 5)
				{
					button_4.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 6)
				{
					button_5.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 7)
				{
					button_6.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 8)
				{
					button_7.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 9)
				{
					button_8.setBackground(Color.RED);
				}
				if(Integer.parseInt(gate_reserved[2]) == 10)
				{
					button_9.setBackground(Color.RED);
				}
			}
		}
	}
}
