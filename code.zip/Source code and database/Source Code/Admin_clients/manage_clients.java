package Admin_clients;

import java.awt.Color;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.security.sasl.SaslException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import Client.Client;
import net.proteanit.sql.DbUtils;
import java.awt.Button;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.TextField;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class manage_clients {

	private JFrame frame;
	private JTable table;
	private JTextField txtUsername;
	private JTextField txtPass;
	private JTextField txtCompany;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					manage_clients window = new manage_clients();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public manage_clients() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBackground(Color.BLACK);
		frame.setBounds(100, 100, 800, 531);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0,52,782,321);
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setForeground(Color.BLACK);
		frame.getContentPane().add(scrollPane);
		table = new JTable();
		scrollPane.setViewportView(table);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(10, 429, 109, 31);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		txtUsername.setText("");
		
		txtPass = new JTextField();
		txtPass.setColumns(10);
		txtPass.setBounds(131, 429, 109, 31);
		frame.getContentPane().add(txtPass);
		txtPass.setText("");
		
		JLabel lblNewLabel = new JLabel("Company");
		lblNewLabel.setFont(new Font("Sitka Small", Font.BOLD, 18));
		lblNewLabel.setBounds(252, 397, 141, 24);
		frame.getContentPane().add(lblNewLabel);
		
		txtCompany = new JTextField();
		txtCompany.setColumns(10);
		txtCompany.setBounds(253, 429, 109, 31);
		frame.getContentPane().add(txtCompany);
		txtCompany.setText("");
		
		Connection conn;
		try {
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/parkings?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
	
    	String query = "Select * from clients";
		PreparedStatement st = conn.prepareStatement(query);
		ResultSet rs = st.executeQuery();
		table.setModel(DbUtils.resultSetToTableModel(rs));
		
		Button button = new Button("Edit");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				int column = 0;
				int row= table.getSelectedRow();
				int client_id = (int) table.getModel().getValueAt(row, column);
				
				String query = "SELECT * FROM clients WHERE ClientID = " + client_id;
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(query);
				
				client_id = -1;
				while(rs.next())
				{
					//System.out.println(client_id);
					client_id = rs.getInt("ClientID");
				}
				
				if(client_id == -1)
				{
	            	JOptionPane.showMessageDialog(null,"Can't find client.","Change error",JOptionPane.ERROR_MESSAGE);
	            	return;
				}
				
				String new_username = txtUsername.getText();
				String new_pass = txtPass.getText();
				String new_company = txtCompany.getText();
				
				query = "Select * from clients";
				st = conn.createStatement();
				rs = st.executeQuery(query);
				
				while(rs.next())
				{
					String user = rs.getString("Username");
					String pass = rs.getString("Pass");
					String company = rs.getString("Company");
					if(user.equals(new_username) || company.equals(new_company))
					{
		            	JOptionPane.showMessageDialog(null,"Credentials taken.","Change error",JOptionPane.ERROR_MESSAGE);
		            	return;
					}
					
				}
				
				if(!new_username.equals(""))
				{
				query = "update clients set Username = ? where ClientID = " + client_id;
				PreparedStatement ps = conn.prepareStatement(query);
				ps.setString(1, new_username);
				ps.executeUpdate();
				}
				
				if(!new_pass.equals(""))
				{
				query = "update clients set Pass = ? where ClientID = " + client_id;
				PreparedStatement ps = conn.prepareStatement(query);
				ps = conn.prepareStatement(query);
				ps.setString(1, new_pass);
				ps.executeUpdate();
				}
				
				if(!new_company.equals(""))
				{
					query = "update clients set Company = ? where ClientID = " + client_id;
					PreparedStatement ps = conn.prepareStatement(query);
					ps = conn.prepareStatement(query);
					ps.setString(1, new_company);
					ps.executeUpdate();
				}
				
				String success = "Client credentials updated." ;
				JOptionPane.showMessageDialog(null,success,"Successful changes",JOptionPane.INFORMATION_MESSAGE);
				
				
				
				
				}
				
				catch(SQLException e3)
				{
					e3.printStackTrace();
				}
				
		    	manage_clients info = new manage_clients();
		    	manage_clients.main(null);
		    	frame.dispose();
				
				
				
				
			}
		});
		button.setForeground(new Color(255, 255, 255));
		button.setFont(new Font("Sitka Display", Font.PLAIN, 14));
		button.setBackground(new Color(0, 0, 128));
		button.setBounds(382, 429, 109, 31);
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("Remove");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {		
				int column = 0;
				int row= table.getSelectedRow();
				int client_id = (int) table.getModel().getValueAt(row, column);
				
		    	try {
		    	Connection conn;
		    	conn=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/parkings?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
					
				String query = "SELECT * FROM clients WHERE ClientID = " + client_id;
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(query);
				
				client_id = -1;
				while(rs.next())
				{
					//System.out.println(client_id);
					client_id = rs.getInt("ClientID");
				}
				
				if(client_id == -1)
				{
	            	JOptionPane.showMessageDialog(null,"Can't find client.","Change error",JOptionPane.ERROR_MESSAGE);
	            	return;
				}
				
				query = "delete from clients where ClientID = " + client_id;
				st = conn.createStatement();
				st.executeUpdate(query);
				
				
				String success = "Client removed." ;
				JOptionPane.showMessageDialog(null,success,"Successful changes",JOptionPane.INFORMATION_MESSAGE);
				
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
		    	
		    	manage_clients info = new manage_clients();
		    	manage_clients.main(null);
		    	frame.dispose();
				
				}
			
		});
		button_1.setForeground(new Color(255, 255, 255));
		button_1.setFont(new Font("Sitka Display", Font.PLAIN, 14));
		button_1.setBackground(new Color(0, 0, 128));
		button_1.setBounds(515, 429, 96, 31);
		frame.getContentPane().add(button_1);
		
		Button button_2 = new Button("Back");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin.Admin info = new Admin.Admin();
				Admin.Admin.main(null);
				frame.dispose();
			}
		});
		button_2.setForeground(new Color(255, 255, 255));
		button_2.setFont(new Font("Sitka Display", Font.PLAIN, 14));
		button_2.setBackground(new Color(0, 0, 128));
		button_2.setBounds(10, 10, 79, 24);
		frame.getContentPane().add(button_2);
		
		Button button_3 = new Button("Logout");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String request = "Logout/";
				Client.send_data_to_server(request);
				frame.dispose();
			}
		});
		button_3.setForeground(new Color(255, 255, 255));
		button_3.setFont(new Font("Sitka Display", Font.PLAIN, 14));
		button_3.setBackground(new Color(0, 0, 128));
		button_3.setBounds(95, 10, 79, 24);
		frame.getContentPane().add(button_3);
		

		
		JLabel username = new JLabel("Username");
		username.setFont(new Font("Sitka Small", Font.BOLD, 18));
		username.setBounds(10, 397, 109, 24);
		frame.getContentPane().add(username);
		
		JLabel pass = new JLabel("Password");
		pass.setFont(new Font("Sitka Small", Font.BOLD, 18));
		pass.setBounds(131, 397, 109, 24);
		frame.getContentPane().add(pass);
		


		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
