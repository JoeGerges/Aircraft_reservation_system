package Parking_reservation;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSeparator;

import Client.Client;
import Client_history.Client_history;
import Login_Screen.Login_System;
import Reservation.Reservation;
import Signup.Signup_Screen;

import javax.swing.JRadioButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Button;

public class Parking_reservation {

	private JFrame frmChoice;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Parking_reservation window = new Parking_reservation();
					window.frmChoice.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Parking_reservation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmChoice = new JFrame();
		frmChoice.getContentPane().setBackground(new Color(255, 255, 255));
		frmChoice.setTitle("Choice");
		frmChoice.setBounds(300, 300, 685, 458);
		frmChoice.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmChoice.getContentPane().setLayout(null);
		
		JLabel lblWhatAreYou = new JLabel("What are you here for?");
		lblWhatAreYou.setFont(new Font("Sitka Small", Font.BOLD, 22));
		lblWhatAreYou.setBounds(329, 13, 309, 38);
		frmChoice.getContentPane().add(lblWhatAreYou);
		
		JRadioButton rdbtnHistory = new JRadioButton("Check out my reservation history");
		rdbtnHistory.setFont(new Font("Sitka Small", Font.PLAIN, 18));
		rdbtnHistory.setBackground(new Color(255, 255, 255));
		rdbtnHistory.setBounds(275, 87, 373, 38);
		frmChoice.getContentPane().add(rdbtnHistory);
		
		JRadioButton rdbtnReservation = new JRadioButton("Reserve a parking spot\r\n");
		rdbtnReservation.setFont(new Font("Sitka Small", Font.PLAIN, 18));
		rdbtnReservation.setBackground(new Color(255, 255, 255));
		rdbtnReservation.setBounds(275, 148, 346, 45);
		frmChoice.getContentPane().add(rdbtnReservation);
		
		Button button = new Button("Proceed");
		button.setFont(new Font("Sitka Small", Font.PLAIN, 14));
		button.setForeground(new Color(255, 255, 255));
		button.setBackground(new Color(0, 0, 128));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (rdbtnHistory.isSelected())
				{
					Connection conn = null;
					try 
						{
						String request = "LoadHistory/"+Client.clientID+"/";
						Client.send_data_to_server(request);
						}			
						catch (Exception e1)
						{
							e1.printStackTrace();
						}		
				}
				
				
				if (rdbtnReservation.isSelected())
				{
					Reservation info = new Reservation();
					Reservation.main(null);
					frmChoice.dispose();
				}
			}
		});
		button.setBounds(275, 199, 333, 38);
		frmChoice.getContentPane().add(button);
		
		Button button_1 = new Button("Logout");
		button_1.setForeground(new Color(255, 255, 255));
		button_1.setBackground(new Color(0, 0, 128));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String request = "Logout/";
				Client.send_data_to_server(request);
				frmChoice.dispose();
			}
		});
		button_1.setBounds(550, 355, 79, 30);
		frmChoice.getContentPane().add(button_1);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(-193, -23, 449, 472);
		frmChoice.getContentPane().add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(Login_System.class.getResource("/images/1 (2).jpg")));
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(369, 256, 150, 142);
		frmChoice.getContentPane().add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon(Login_System.class.getResource("/images/Thinking2.png")));
	}
}
