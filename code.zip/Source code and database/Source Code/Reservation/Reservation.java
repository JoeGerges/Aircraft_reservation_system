package Reservation;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.awt.Choice;
import java.awt.Label;
import java.awt.Color;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import java.util.Calendar;
import javax.swing.JToggleButton;
import com.toedter.calendar.JDayChooser;

import Client.Client;
import ClientInfo.ClientInfo;
import Login_Screen.Login_System;
import Parking_reservation.Parking_reservation;

import com.toedter.calendar.JCalendar;
import javax.swing.border.BevelBorder;
import java.awt.Button;

public class Reservation {

	private JFrame frmReservationWindow;
	
	//ClientInfo myClient = Login_System.getClientInfo();
	
	public static String reservation_date;
	public static String reservation_time;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reservation window = new Reservation();
					window.frmReservationWindow.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Reservation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @return 
	 * @throws SQLException 
	 */
	
	private void initialize() {
		frmReservationWindow = new JFrame();
		frmReservationWindow.getContentPane().setForeground(new Color(255, 255, 255));
		frmReservationWindow.getContentPane().setBackground(Color.WHITE);
		frmReservationWindow.setBackground(new Color(0, 0, 128));
		frmReservationWindow.setTitle("Reservation Window");
		frmReservationWindow.setBounds(100, 100, 934, 593);
		frmReservationWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmReservationWindow.getContentPane().setLayout(null);
		
		JLabel lblReserveYourParking = new JLabel("RESERVATION DETAILS");
		lblReserveYourParking.setForeground(Color.BLACK);
		lblReserveYourParking.setFont(new Font("Sitka Small", Font.BOLD, 20));
		lblReserveYourParking.setBounds(601, 13, 348, 42);
		frmReservationWindow.getContentPane().add(lblReserveYourParking);
		
		JLabel lblNewLabel = new JLabel("Pick a date");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Sitka Small", Font.BOLD, 18));
		lblNewLabel.setBounds(556, 85, 148, 22);
		frmReservationWindow.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Pick a time slot");
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Sitka Small", Font.BOLD, 18));
		lblNewLabel_1.setBounds(556, 349, 231, 22);
		frmReservationWindow.getContentPane().add(lblNewLabel_1);
		
		
		Choice timeChoice = new Choice();
		timeChoice.setForeground(Color.BLACK);
		timeChoice.setBackground(Color.WHITE);
		timeChoice.setBounds(556, 377, 242, 32);
		frmReservationWindow.getContentPane().add(timeChoice);
		timeChoice.add("00:00 - 02:00");
		timeChoice.add("02:00 - 04:00");
		timeChoice.add("04:00 - 06:00");
		timeChoice.add("06:00 - 08:00");
		timeChoice.add("08:00 - 10:00");
		timeChoice.add("10:00 - 12:00");
		timeChoice.add("12:00 - 14:00");
		timeChoice.add("14:00 - 16:00");
		timeChoice.add("16:00 - 18:00");
		timeChoice.add("18:00 - 20:00");
		timeChoice.add("20:00 - 22:00");
		timeChoice.add("22:00 - 00:00");
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setForeground(Color.LIGHT_GRAY);
		separator_2.setBounds(366, 68, 0, 400);
		frmReservationWindow.getContentPane().add(separator_2);
		
		JCalendar calendar = new JCalendar();
		calendar.getMonthChooser().setForeground(Color.WHITE);
		calendar.getMonthChooser().setBackground(Color.WHITE);
		calendar.setWeekdayForeground(Color.WHITE);
		calendar.getDayChooser().getDayPanel().setForeground(Color.WHITE);
		calendar.setBorder(null);
		calendar.getDayChooser().getDayPanel().setBorder(null);
		calendar.getDayChooser().setWeekOfYearVisible(false);
		calendar.getDayChooser().setBorder(null);
		calendar.getMonthChooser().getComboBox().setBackground(new Color(255, 255, 255));
		calendar.setSundayForeground(new Color(255, 0, 0));
		calendar.setDecorationBackgroundColor(new Color(255, 255, 255));
		calendar.setBackground(new Color(255, 255, 255));
		calendar.getDayChooser().setDayBordersVisible(true);
		calendar.getDayChooser().setDecorationBackgroundColor(new Color(255, 255, 255));
		calendar.getDayChooser().setForeground(new Color(0, 0, 128));
		calendar.getDayChooser().setWeekdayForeground(new Color(0, 0, 139));
		calendar.getDayChooser().getDayPanel().setBackground(Color.WHITE);
		calendar.setBounds(558, 107, 242, 211);
		frmReservationWindow.getContentPane().add(calendar);
		
		Button button = new Button("See available gates");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LocalDate now = LocalDate.now();
				Date today = java.sql.Date.valueOf(now);
				java.util.Date reservationDate = calendar.getDate();
				java.sql.Date resDate = new java.sql.Date(reservationDate.getTime());
				String timeSlot = timeChoice.getSelectedItem();
				
				if(resDate.before(today))
				{
					JOptionPane.showMessageDialog(null,"The date can't be before the current date!","Login Error",JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				reservation_time = timeSlot;
				reservation_date = resDate.toString();
				Client.pickedDate = reservation_date;
				Client.timeSlot = timeSlot;
				String request = "Availability/"+reservation_time+"/"+reservation_date+"/";
				frmReservationWindow.dispose();
				Client.send_data_to_server(request);
			}
		});
		button.setFont(new Font("Dialog", Font.PLAIN, 16));
		button.setBackground(new Color(0, 0, 128));
		button.setBounds(556, 415, 242, 32);
		frmReservationWindow.getContentPane().add(button);
		
		Button button_1 = new Button("Back");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmReservationWindow.dispose();
				Parking_reservation info = new Parking_reservation();
				Parking_reservation.main(null);
			}
		});
		button_1.setFont(new Font("Dialog", Font.PLAIN, 16));
		button_1.setBackground(new Color(0, 0, 128));
		button_1.setBounds(758, 511, 73, 32);
		frmReservationWindow.getContentPane().add(button_1);
		
		Button button_2 = new Button("Logout");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String request = "Logout/";
				Client.send_data_to_server(request);
				frmReservationWindow.dispose();
			}
		});
		button_2.setFont(new Font("Dialog", Font.PLAIN, 16));
		button_2.setBackground(new Color(0, 0, 128));
		button_2.setBounds(833, 511, 73, 32);
		frmReservationWindow.getContentPane().add(button_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(-284, 0, 825, 542);
		frmReservationWindow.getContentPane().add(lblNewLabel_3);
		lblNewLabel_3.setIcon(new ImageIcon(Login_System.class.getResource("/images/175818.gif")));
	
		
		
		
		
	}
}
