package Client;
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import Login_Screen.Login_System;
import Reservation.Reservation;
import Signup.Signup_Screen;

public class Client
{	
	public static String company;
	public static int	clientID;
	public static String username;
	public static String password;
	public static String pickedDate;
	public static int gate_number;
	public static String timeSlot;
	public static String request;
	public static ResultSet history;
	public static DefaultTableModel model;
	public static JTable table;
	public static String[] gates_not_available = {"","","","","","","","","",""};
	public static int reservation_number;
	
	
	public static void set_client_id(int clientId)
	{
		clientID = clientId;
	}
	
	public static int read_clientID()
	{
		return clientID;
	}
	
	public static void set_client_username(String user)
	{
		username = user;
	}
	
	public static String get_username()
	{
		return username;
	}
	
	public static void set_client_password(String pass)
	{
		password = pass;
	}
	
	public static String get_password()
	{
		return password;
	}
	
	public static void set_client_company(String comp)
	{
		company = comp;
	}
	
	public static String get_company()
	{
		return company;
	}
	
	
	static Socket clientSocket;
	
	static BufferedReader inFromServer;
	static OutputStream outToServer;
	
	static void instantiateClientSocket(int portNumber) throws UnknownHostException, IOException
	{
		Client.clientSocket = new Socket("localhost", portNumber); 
	}
	
	public static void send_data_to_server(String request)
	{
        PrintWriter p = new PrintWriter(Client.outToServer,true);
	    p.println(request);
	}
	
	public static void parse_result(String response,DefaultTableModel model)
	{
		String[] rows = response.split("/");
		for(int i=1;i<rows.length;i++)
		{
			String[] column = rows[i].split("\\*");
        	model.addRow(new Object[] {column[0],column[1],column[2],column[3],column[4],column[5]});
		}
	}
	
    
    static BufferedReader inFromUser = 
    new BufferedReader(new InputStreamReader(System.in));
	public static String set_client_company; 
	static JFrame f = new JFrame();

    
	public static void main(String argv[]) throws Exception 
    { 
	    Client.instantiateClientSocket(3602);
        
        Client.inFromServer = 
        new BufferedReader(new
        InputStreamReader(Client.clientSocket.getInputStream()));
        
        Client.outToServer = Client.clientSocket.getOutputStream();
        String response = "";
        table =  new JTable(new DefaultTableModel(new Object[] {"Reservation Number", "Client ID","Company","Gate Number","Reservation Date","Reservation Time"}, 0));
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        table.setBackground(Color.WHITE);
        
        Login_System.main(null);
        while(true)
        {
            response = inFromServer.readLine();
            String[] loginResponse = response.split("/");
            //String[] history = response.split("\n");
            
            if(loginResponse[0].equals("GoodCredentials"))
            {
	            Client.set_client_username(loginResponse[1]);
	            Client.set_client_password(loginResponse[2]);
	            Client.set_client_company(loginResponse[3]);
	            Client.set_client_id(Integer.parseInt(loginResponse[4]));
            	Login_System.dispose_of_frame_and_next();
            }
            
            if(loginResponse[0].equals("Admin"))
            {
            	Login_System.dispose_frame();
            }
            
            if(loginResponse[0].equals("BadCredentials"))
            {
            	JOptionPane.showMessageDialog(null,"Invalid Login Credentials.","Login Error",JOptionPane.ERROR_MESSAGE);
            	Login_System.clear_username_and_pass();
            }
            
            if(response.equals("SignedUp"))
            {
				String success = "Congratulation you registered successfully! " ;
				JOptionPane.showMessageDialog(null,success,"Signup Successful",JOptionPane.INFORMATION_MESSAGE);
				Signup_Screen.clear_all();
            }
            
            if(response.equals("CompanyTaken"))
            {
				JOptionPane.showMessageDialog(null,"Company name is taken.","Signup Error",JOptionPane.ERROR_MESSAGE);
				Signup_Screen.clear_company();
            }
            
            if(response.equals("verifypassword#password"))
            {
				JOptionPane.showMessageDialog(null,"The Verify password field does not match your password.","Signup Error",JOptionPane.ERROR_MESSAGE);
				Signup_Screen.clear_verify_password();
            }
            
            if(response.equals("UsernameTaken"))
            {
				JOptionPane.showMessageDialog(null,"Username is taken.","Signup Error",JOptionPane.ERROR_MESSAGE);
				Signup_Screen.clear_username();
            }
            
            if(loginResponse[0].equals("YourHistory"))
            {
            	model = new DefaultTableModel();
            	table =  new JTable(new DefaultTableModel(new Object[] {"Reservation Number", "Client ID","Company","Gate Number","Reservation Date","Reservation Time"}, 0));
                model = (DefaultTableModel) table.getModel();
            	parse_result(response,model);

				f = new JFrame();
				f.setBackground(Color.WHITE);
				f.getContentPane().setForeground(new Color(0, 0, 0));
				f.getContentPane().setBackground(new Color(255, 255, 255));
				f.setBackground(new Color(0, 0, 0));
				f.setVisible(true);
				f.setBounds(100, 100, 832, 521);
				//frmChoice.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				//f.getContentPane().setLayout(null);
				table.setVisible(true);
				f.setTitle("History");
				table.setBounds(100, 100, 200, 200);
				JScrollPane sp = new JScrollPane(table);
				f.add(sp);
				f.setSize(700,400);
            }
            
            if(loginResponse[0].equals("Reserved"))
            {
    			String success = "Parking spot reserved successfully. ";
				JOptionPane.showMessageDialog(null,success,"Reservation Successful",JOptionPane.INFORMATION_MESSAGE);
            }
            
            if(loginResponse[0].equals("Availability"))
            {
            	for(int i = 0; i<gates_not_available.length; i++)
            	{
            		gates_not_available[i] = "";
            	}
            	
            	for(int i = 1; i<loginResponse.length; i++)
            	{
            		gates_not_available[i-1] = loginResponse[i];
            	}  	
            	Available_gates.Available_gates.main(null);
            }
            
            if(loginResponse[0].equals("Refresh"))
            {
            	for(int i = 0; i<gates_not_available.length; i++)
            	{
            		gates_not_available[i] = "";
            	}
            	
            	for(int i = 1; i<loginResponse.length; i++)
            	{
            		gates_not_available[i-1] = loginResponse[i];
            	}  	
            	Available_gates.Available_gates.main(null);
            }
            
            if(loginResponse[0].equals("GateHasJustBeenTaken"))
            {
				JOptionPane.showMessageDialog(null,"Gate already taken.","Reservation Error",JOptionPane.ERROR_MESSAGE);
            }
            
            if(loginResponse[0].equals("Logout"))
            {
    			String success = "You logged out successfully. ";
    			f.dispose();
    	        clientSocket.close();
				JOptionPane.showMessageDialog(null,success,"Logout Successful",JOptionPane.INFORMATION_MESSAGE);
				break;
            }
        }
        clientSocket.close();
        
        

    }
 
	
	
    
}
