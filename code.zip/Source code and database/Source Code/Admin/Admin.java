package Admin;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

import Client.Client;
import Login_Screen.Login_System;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.Button;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Admin {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin window = new Admin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Admin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 598, 491);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Button Logout = new Button("Logout");
		Logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String request = "Logout/";
				Client.send_data_to_server(request);
				frame.dispose();
			}
		});
		Logout.setForeground(Color.WHITE);
		Logout.setFont(new Font("Sitka Small", Font.PLAIN, 14));
		Logout.setBackground(new Color(0, 0, 128));
		Logout.setBounds(478, 396, 92, 38);
		frame.getContentPane().add(Logout);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Change a reservation");
		rdbtnNewRadioButton.setForeground(Color.WHITE);
		rdbtnNewRadioButton.setFont(new Font("Sitka Small", Font.BOLD, 18));
		rdbtnNewRadioButton.setBounds(29, 70, 305, 25);
		frame.getContentPane().add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setOpaque(false);
		rdbtnNewRadioButton.setContentAreaFilled(false);
		rdbtnNewRadioButton.setBorderPainted(false);
		
		
		
		JLabel lblAdminPage = new JLabel("Admin Page");
		lblAdminPage.setForeground(Color.WHITE);
		lblAdminPage.setFont(new Font("Sitka Small", Font.BOLD, 22));
		lblAdminPage.setBounds(115, 13, 145, 38);
		frame.getContentPane().add(lblAdminPage);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Manage my clients");
		rdbtnNewRadioButton_1.setForeground(Color.WHITE);
		rdbtnNewRadioButton_1.setFont(new Font("Sitka Small", Font.BOLD, 18));
		rdbtnNewRadioButton_1.setBackground(Color.BLACK);
		rdbtnNewRadioButton_1.setBounds(29, 127, 242, 38);
		frame.getContentPane().add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.setOpaque(false);
		rdbtnNewRadioButton_1.setContentAreaFilled(false);
		rdbtnNewRadioButton_1.setBorderPainted(false);
		
		Button button = new Button("Proceed");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rdbtnNewRadioButton.isSelected())
				{
					Admin_change.change_reservation.main(null);
				}
				
				if(rdbtnNewRadioButton_1.isSelected())
				{
					Admin_clients.manage_clients.main(null);
				}
				
				frame.dispose();
			}
		});
		button.setFont(new Font("Sitka Small", Font.PLAIN, 14));
		button.setForeground(new Color(255, 255, 255));
		button.setBackground(new Color(0, 0, 128));
		button.setBounds(29, 189, 242, 38);
		frame.getContentPane().add(button);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(-282, -183, 1340, 720);
		frame.getContentPane().add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(Login_System.class.getResource("/images/maxresdefault.jpg")));
	}
}
