package Login_Screen;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;

import Client.Client;
import ClientInfo.ClientInfo;
import Parking_reservation.Parking_reservation;
import Signup.Signup_Screen;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.JPanel;
import java.awt.Button;
import javax.swing.ImageIcon;

public class Login_System {

	private	static JFrame frmLoginPage;
	private static JTextField textUsername;
	private static JPasswordField textPassword;
	
	public static void clear_username_and_pass()
	{
		textUsername.setText(null);
		textPassword.setText(null);
	}
	
	public static void dispose_of_frame_and_next()
	{
		frmLoginPage.dispose();
		Parking_reservation info = new Parking_reservation();
		Parking_reservation.main(null);
	}
	
	public static void dispose_frame()
	{
		frmLoginPage.dispose();
		Admin.Admin info = new Admin.Admin();
		Admin.Admin.main(null);
	}

	/**
	 * Launch the application.
	 */
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_System window = new Login_System();
					window.frmLoginPage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login_System() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLoginPage = new JFrame();
		frmLoginPage.setForeground(new Color(0, 0, 139));
		frmLoginPage.setTitle("Login page\r\n");
		frmLoginPage.getContentPane().setBackground(new Color(255, 255, 255));
		frmLoginPage.getContentPane().setForeground(new Color(0, 0, 128));
		frmLoginPage.setBackground(new Color(0, 0, 139));
		frmLoginPage.setBounds(500, 500, 670, 396);
		frmLoginPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLoginPage.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setForeground(new Color(0, 0, 0));
		lblLogin.setBackground(Color.WHITE);
		lblLogin.setFont(new Font("Sitka Small", Font.BOLD, 22));
		lblLogin.setBounds(439, 13, 87, 28);
		frmLoginPage.getContentPane().add(lblLogin);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setForeground(new Color(0, 0, 0));
		lblUsername.setFont(new Font("Sitka Small", Font.BOLD, 17));
		lblUsername.setBounds(330, 88, 139, 28);
		frmLoginPage.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(new Color(0, 0, 0));
		lblPassword.setFont(new Font("Sitka Small", Font.BOLD, 17));
		lblPassword.setBounds(330, 158, 139, 24);
		frmLoginPage.getContentPane().add(lblPassword);
		
		textUsername = new JTextField();
		textUsername.setBounds(330, 114, 176, 31);
		frmLoginPage.getContentPane().add(textUsername);
		textUsername.setColumns(10);
		
		textPassword = new JPasswordField();
		textPassword.setBounds(330, 180, 176, 31);
		frmLoginPage.getContentPane().add(textPassword);
		
		JLabel lblSignupHere = new JLabel("don't have an account? Signup ");
		lblSignupHere.setForeground(new Color(0, 0, 0));
		lblSignupHere.setFont(new Font("Sitka Small", Font.PLAIN, 15));
		lblSignupHere.setBounds(310, 312, 247, 24);
		frmLoginPage.getContentPane().add(lblSignupHere);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(433, 291, -212, -9);
		frmLoginPage.getContentPane().add(separator);
		
		Button button = new Button("Login");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username = textUsername.getText();
				String password = textPassword.getText();
				if(username.isEmpty() || password.isEmpty())
				{
	            	JOptionPane.showMessageDialog(null,"Do not leave any field empty.","Login Error",JOptionPane.ERROR_MESSAGE);
				}
				
				
				else
				{
					String request = "Login/"+username+"/"+password+"/";
					Client.send_data_to_server(request);
				}
			}
			
		});
		button.setFont(new Font("Sitka Small", Font.PLAIN, 16));
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(0, 0, 128));
		button.setBounds(331, 228, 175, 31);
		frmLoginPage.getContentPane().add(button);
		
		Button button_1 = new Button("Here");
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(0, 0, 139));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmLoginPage.dispose();
				Signup_Screen info = new Signup_Screen();
				Signup_Screen.main(null);
			}
		});
		button_1.setBounds(563, 312, 79, 24);
		frmLoginPage.getContentPane().add(button_1);
		
		JLabel lblNewLabel = new JLabel("");
		frmLoginPage.getContentPane().add(lblNewLabel);
		lblNewLabel.setBounds(12,-76,288,425);
		lblNewLabel.setIcon(new ImageIcon(Login_System.class.getResource("/images/resize2.jpg")));
	}
}
