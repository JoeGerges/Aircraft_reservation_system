package ClientInfo;

import java.sql.ResultSet;

public class ClientInfo {
	public String company;
	public int	clientID;
	public String username;
	public String password;
	public java.sql.Date pickedDate;
	public String timeSlot;
	public String request;
	public ResultSet history;
	
	public void set_client_id(int clientID)
	{
		this.clientID = clientID;
	}
	
	public int read_clientID()
	{
		return this.clientID;
	}
	
}
