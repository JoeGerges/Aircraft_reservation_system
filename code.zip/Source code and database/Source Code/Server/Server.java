package Server;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.awt.print.PrinterException;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import Client.Client;
import ClientInfo.ClientInfo;
import Client_history.Client_history;
import net.proteanit.sql.DbUtils;

public class Server {
	public static Connection conn;
	public static Connection ConnectToDB(Connection connection)
	{
		try			 
		{
			connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/parkings?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
				             
			if(connection!=null)
			{
				System.out.println("Waiting for clients ...");
			}
			
		} 
			
		catch(Exception e) 
		{
			System.out.println("Connection failed");
			e.printStackTrace();
		}
		
		return connection;
	}
	
	
	private int port = 3602;

	private ServerSocket serverSocket;

	public void acceptConnections() {

		     try {
		   //similar to the WelcomeSocket in the PowerPoint slides
		      serverSocket = new ServerSocket(port);
		    }
		    catch (IOException e) {
		      System.err.println("ServerSocket instantiation failure");
		      e.printStackTrace();
		      System.exit(0);
		    }
		   //Entering the infinite loop
		     while (true) {
		      try {
		  //wait for a TCP handshake initialization (arrival of a "SYN" packet)
		        Socket newConnection = serverSocket.accept();
		        System.out.println("accepted connection");

		 //Now, pass the connection socket created above to a thread and run it in it
		  
		  //First create the thread and pass the connection socket to it
		  //This is a non-blocking function: constructor of the class ServerThread
		        ServerThread st = new ServerThread(newConnection);

		 //Then, start the thread, and go back to waiting for another TCP connection
		  //This also is not blocking

		        new Thread(st).start();
		      }
		      catch (IOException ioe) {
		        System.err.println("server accept failed");
		      }
		    }
		   }
	
	public static void main(String args[]) throws ClassNotFoundException {

		  Server server = null;
		     //Instantiate an object of this class. This will load the JDBC database driver
		  server = new Server();
		  Server.conn = Server.ConnectToDB(Server.conn);
		 //call this function, which will start it all...
		  server.acceptConnections();
		   }
	  
	  
	  
	  class ServerThread implements Runnable {

		    private Socket socket;
		    private DataInputStream datain;
		    private OutputStream outToClient; 

		    ////////////////////////////////////
		    public ServerThread(Socket socket) {
		   //Inside the constructor: store the passed object in the data member  
		      this.socket = socket;
		    }

		    ////////////////////////////////////
		    //This is where you place the code you want to run in a thread
		    //Every instance of a ServerThread will handle one client (TCP connection)
		    public void run() {
		      try {
		     //Input and output streams, obtained from the member socket object  
		        datain = new DataInputStream(new BufferedInputStream
		          (socket.getInputStream()));
		        outToClient = socket.getOutputStream();
		      }
		      catch (IOException e) {
		  		        return;
		      }
		    
		      byte[] ba = new byte[256];
		      boolean conversationActive = true;
		      String fromClient;
		        
		      while(conversationActive)
		      {
		        try {
		    //read from the input stream buffer (read a message from client)
		           datain.read(ba,0,256);
		           fromClient = new String(ba);

		           int clientID = 0;
		           String[] request = fromClient.split("/");
		           
		           if (request[0].equals("Logout"))
		           {
		        	   conversationActive = false;
		        	   String status = "Logout/";
		        	   PrintWriter p = new PrintWriter(outToClient,true);
		        	   p.println(status);
		        	   
		           }
		           
		           
		           if(request[0].equals("AdminChange"))
		           {
		        	   if(request[4].equals(""))
		        	   {
		        		   request[4] = "0";
		        	   }
		        	   change_reservation(Integer.parseInt(request[1]),request[2],request[3],Integer.parseInt(request[4]));
		           }
		           
		           if(request[0].equals("AdminDelete"))
		           {
		        	   delete_reservation(Integer.parseInt(request[1]));
		           }

		           if(request[0].contentEquals("Login")) {
		  //Write to the output stream buffer (send a message to client)
		        	   boolean admin = false;
		        	   String username = request[1];
		        	   String password = request[2];
		        	   if(username.equals("admin") && password.equals("adminpass"))
		        	   {
		        		   String status = "Admin/";
			        	   PrintWriter p = new PrintWriter(outToClient,true);
			        	   p.println(status);
		        		   admin=true;
		        	   }
		        	   
		        	   if(!admin)
		        	   {
		        	   String status = Server.Login(username,password);
		               String[] loginResponse = status.split("/");
		        	   PrintWriter p = new PrintWriter(outToClient,true);
		        	   p.println(status);
		        	   }
		           }
		           
		           if(request[0].equals("Signup"))
		           {
		        	   String signup_username = request[1];
		        	   String signup_password = request[2];
		        	   String signup_verifyPassword = request[3];
		        	   String signup_company = request[4];
		        	   String status = Signup(signup_username, signup_password, signup_company, signup_verifyPassword);
		        	   PrintWriter p = new PrintWriter(outToClient,true);
		        	   p.println(status);
		           }
		           
		           if(request[0].equals("LoadHistory"))
		           {
		        	   String status = Load_History(Integer.parseInt(request[1]));
		        	   PrintWriter p = new PrintWriter(outToClient,true);
		        	   p.println(status);
		           }
		           
		           if(request[0].equals("Availability"))
		           {
		        	   String status = check_gate_availability(request[1],request[2]);
		        	   PrintWriter p = new PrintWriter(outToClient,true);
		        	   p.println(status);
		           }
		           
		           if(request[0].equals("Reserve"))
		           {
		        	   String status = Reserve(Integer.parseInt(request[1]),request[2],request[3],request[4],Integer.parseInt(request[5]));
		        	   PrintWriter p = new PrintWriter(outToClient,true);
		        	   p.println(status);
		           }
		           
		           if(request[0].equals("Refresh"))
		           {
		        	   String status = check_gate_availability(request[1],request[2]);
		        	   PrintWriter p = new PrintWriter(outToClient,true);
		        	   p.println(status);
		           }
		           

		        }
		        
		        
		        catch (IOException ioe) {
		        	ioe.printStackTrace();
		          conversationActive = false;
		        }
		      }
		      try {
		        System.out.println("closing socket");
		        datain.close();
		        outToClient.close();
		  //When the server receives a "Q", we arrive here
		        socket.close();
		      }
		      catch (IOException e) {
		      }
		    }
		    
	  }

		////////////////////////////////////////////////////////////////////////////
		 //This function is for communicating with the database server
		 //using API provided by the JDBC driver loaded at the top
		    private static String Login(String username, String password) throws IOException {
		      try {
		        String query = "SELECT * FROM clients";
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(query);
				boolean loggedIn = false;
				
					while(rs.next())
					{
						String user = rs.getString("Username");
						String pass = rs.getString("Pass");
						String company = rs.getString("Company");
						int clientID = rs.getInt("ClientID");
						
						if (user.matches(username) && pass.matches(password))
						{	
							return "GoodCredentials/"+username+"/"+password+"/"+company+"/"+clientID+"/";
						}
					}

		      }
				
		      catch (SQLException e) {
		        System.out.println(e.getMessage());
		      }
		      
		      return "BadCredentials";
		    }
		    
		    
		    private static String Signup(String username,String password,String company,String verifyPassword)
		    {
		    	try {		
		    		
		    		if(username.isEmpty() || password.isEmpty() || company.isEmpty() || verifyPassword.isEmpty())
		    		{
		    			return "EmptyField";
		    		}
		    		
					String query = "SELECT Company FROM clients";
					Statement st = conn.createStatement();
					ResultSet rs = st.executeQuery(query);
					
					while(rs.next())
					{
						String comp = rs.getString("Company");
						if (comp.equals(company))
						{			
							return "CompanyTaken";
						}
					}
					
					query = "SELECT Username FROM clients";
					st = Server.conn.createStatement();
					rs = st.executeQuery(query);
					while(rs.next())
					{
						String user = rs.getString("Username");
						if (user.equals(username))
						{
							return "UsernameTaken";
						}
					}
					
					if (!password.equals(verifyPassword))
					{
						return "verifypassword#password";
					}
					

					query = "INSERT INTO clients (Company,Username,Pass)"+"values(?, ?, ?)";
					PreparedStatement preparedSt = conn.prepareStatement(query);
					preparedSt.setString(1, company);
					preparedSt.setString(2, username);
					preparedSt.setString(3, password);
					preparedSt.execute();
		    }
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
				return "SignedUp";
		  }
		    
		    private static String Reserve(int ClientID, String company,String reservation_date,String reservation_time,int gate_number)
		    {
		    	boolean taken = false;
		    	try {
		    		

		    		conn=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/parkings?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
						
					String query = "SELECT * FROM clienthistory";
					Statement st = conn.createStatement();
					ResultSet rs = st.executeQuery(query);
					while(rs.next())
					{
						String time = rs.getString("Time_Slot");
						String date = rs.getString("Reservation_Date");
						int gateNum = rs.getInt("Gates_GateNumber");
						if(time.equals(reservation_time) && date.equals(reservation_date) && gate_number == gateNum)
						{
							taken = true;
							return "GateHasJustBeenTaken/";
						}
					}
				if(!taken)
				{
		    	query = "INSERT INTO clienthistory (Clients_ClientID,Gates_GateNumber,Reservation_Date,Time_Slot, Company)"+"values(?, ?, ?, ?, ?)";
				PreparedStatement preparedSt = conn.prepareStatement(query);
				preparedSt.setInt(1, ClientID);
				preparedSt.setInt(2, gate_number);
				preparedSt.setString(3, reservation_date);
				preparedSt.setString(4, reservation_time);
				preparedSt.setString(5, company);
				preparedSt.execute();
				}
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return "Reserved/"+gate_number+"/"+reservation_date+"/"+reservation_time+"/";

		    }

		    private static String Load_History(int clientID)
		    {
		    	ResultSet rs = null;
		    	String final_result = "YourHistory/";
		    	try 
				{
			    	String query = "Select * from clienthistory where Clients_ClientID = " + clientID;
					Statement st = conn.createStatement();
					rs = st.executeQuery(query);
					while(rs.next())
					{
					int reservation_number = rs.getInt("Reservation_Number");
					int client_id = rs.getInt("Clients_ClientID");
					int gate_number = rs.getInt("Gates_GateNumber");
					String company = rs.getString("Company");
					String reservation_date = rs.getString("Reservation_Date");
					String reservation_time = rs.getString("Time_Slot");
					final_result += reservation_number + "*" + client_id + "*" + company + "*" + gate_number + "*"+ reservation_date +"*"+ reservation_time + "*" + "/";
					}

				}		
		    	
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
				return final_result;

		    }
		    
		    private static String check_gate_availability(String reservation_time,String reservation_date)
		    {
				String gates_not_available = "";
				try {
				conn=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/parkings?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
				
				String query = "SELECT * FROM clienthistory";
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(query);
				while(rs.next())
				{
					String time = rs.getString("Time_Slot");
					String date = rs.getString("Reservation_Date");
					if(time.equals(reservation_time) && date.equals(reservation_date))
					{
						gates_not_available = gates_not_available + "Gate Number " + rs.getInt("Gates_GateNumber") + " /";
					}
				}
				}
				
				 catch (SQLException e1) {
						e1.printStackTrace();
					}
				return "Availability/" + gates_not_available;
		    }
		    
		    private static String refresh_gates(String reservation_time,String reservation_date)
		    {
				String gates_not_available = "";
				try {
				conn=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/parkings?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
				
				String query = "SELECT * FROM clienthistory";
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(query);
				while(rs.next())
				{
					String time = rs.getString("Time_Slot");
					String date = rs.getString("Reservation_Date");
					if(time.equals(reservation_time) && date.equals(reservation_date))
					{
						gates_not_available = gates_not_available + "Gate Number " + rs.getInt("Gates_GateNumber") + " /";
					}
				}
				}
				
				 catch (SQLException e1) {
						e1.printStackTrace();
					}
				return "Availability/" + gates_not_available;
		    }
		    
		    private static void change_reservation(int reservation_number, String reservation_time,String reservation_date,int gate_num)
		    {

				try {
					conn=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/parkings?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","root");
				
					
				String query = "SELECT * FROM clienthistory WHERE Reservation_Number = " + reservation_number;
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(query);
				String old_time = "";
				int old_gate = 0;
				String old_date = "";
				int res_num = 0;
				
				while(rs.next())
				{
					res_num = rs.getInt("Reservation_Number");
					old_time = rs.getString("Time_Slot");
					old_date = rs.getString("Reservation_Date");
					old_gate = rs.getInt("Gates_GateNumber");
				}
				
				if(res_num == 0)
				{
					JOptionPane.showMessageDialog(null,"Wrong reservation number.","Change error",JOptionPane.ERROR_MESSAGE);
	            	return;
				}
				
				if(gate_num < 0 || gate_num >10)
				{
					JOptionPane.showMessageDialog(null,"Wrong gate number.","Change error",JOptionPane.ERROR_MESSAGE);
	            	return;
				}
				
				query = "SELECT * FROM clienthistory WHERE Gates_GateNumber = " + gate_num;
				st = conn.createStatement();
				rs = st.executeQuery(query);
				
				while(rs.next())
				{
					if(rs.getString("Reservation_Date").equals(reservation_date) && rs.getString("Time_Slot").equals(reservation_time))
					{
		            	JOptionPane.showMessageDialog(null,"Gate taken at this date and time.","Change error",JOptionPane.ERROR_MESSAGE);
		            	return;
					}
				}
					
				
				if( gate_num != 0)
				{
				  query = "UPDATE clienthistory SET Gates_GateNumber = ? where Reservation_Number= ?";
			      PreparedStatement preparedStmt = conn.prepareStatement(query);
			      preparedStmt.setInt(1, gate_num);
			      preparedStmt.setInt(2, reservation_number);
			      preparedStmt.executeUpdate();
				}
				
				if (gate_num == 0)
				{
					query = "UPDATE clienthistory SET Gates_GateNumber = ? where Reservation_Number= ?";
				      PreparedStatement preparedStmt = conn.prepareStatement(query);
				      preparedStmt.setInt(1, old_gate);
				      preparedStmt.setInt(2, reservation_number);
				      preparedStmt.executeUpdate();	
				}


					if(!reservation_time.equals(""))
					{
					  query = "UPDATE clienthistory SET Time_Slot = ? where Reservation_Number = ?";
				      PreparedStatement preparedStmt = conn.prepareStatement(query);
				      preparedStmt.setString(1, reservation_time);
				      preparedStmt.setInt(2, reservation_number);
				      preparedStmt.executeUpdate();
					}
					
					if(reservation_time.equals(""))
					{
						  query = "UPDATE clienthistory SET Time_Slot = ? where Reservation_Number = ?";
					      PreparedStatement preparedStmt = conn.prepareStatement(query);
					      preparedStmt.setString(1, old_time);
					      preparedStmt.setInt(2, reservation_number);
					      preparedStmt.executeUpdate();
					}
					
					if(!reservation_date.equals(""))
					{
					query = "UPDATE clienthistory SET Reservation_Date = ? where Reservation_Number = ?";
				    PreparedStatement preparedStmt = conn.prepareStatement(query);
				    preparedStmt.setString(1, reservation_date);
				    preparedStmt.setInt(2, reservation_number);
				    preparedStmt.executeUpdate();
					}
					
					if(reservation_date.equals("")) {
						query = "UPDATE clienthistory SET Reservation_Date = ? where Reservation_Number = ?";
					    PreparedStatement preparedStmt = conn.prepareStatement(query);
					    preparedStmt.setString(1, old_date);
					    preparedStmt.setInt(2, reservation_number);
					    preparedStmt.executeUpdate();
					}
					
					String success = "Changes made successfuly." ;
					JOptionPane.showMessageDialog(null,success,"Successful changes",JOptionPane.INFORMATION_MESSAGE);
					
				
				
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		    }
		    
		    private static void delete_reservation(int reservation_number)
		    {
		    	
		    	try {
		    	int reservation_num = 0;
				String query = "SELECT * FROM clienthistory WHERE Reservation_Number = " + reservation_number;
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery(query);
				while(rs.next())
				{
					reservation_num = rs.getInt("Reservation_Number");
				}
				
				if(reservation_num == 0)
				{
	            	JOptionPane.showMessageDialog(null,"Can't find this reservation.","Change error",JOptionPane.ERROR_MESSAGE);
	            	return;
				}
				
				query = "delete from clienthistory where Reservation_Number = " + reservation_number;
				st = conn.createStatement();
				st.executeUpdate(query);
				String success = "Reservation deleted!" ;
				JOptionPane.showMessageDialog(null,success,"Successful changes",JOptionPane.INFORMATION_MESSAGE);
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
}
		    
		
