package Signup;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import Client.Client;
import Login_Screen.Login_System;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Button;
import javax.swing.ImageIcon;

public class Signup_Screen {

	private JFrame frmSignup;
	private static JTextField textUsername;
	private static JPasswordField textNewPassword;
	private static JPasswordField textVerifyPassword;
	private static JTextField textCompanyName;
	
	public static void clear_username()
	{
		textUsername.setText(null);
	}
	
	public static void clear_password()
	{
		textNewPassword.setText(null);
	}
	
	public static void clear_verify_password()
	{
		textVerifyPassword.setText(null);
	}
	
	public static void clear_company()
	{
		textCompanyName.setText(null);
	}
	
	public static void clear_all()
	{
		textUsername.setText(null);
		textNewPassword.setText(null);
		textVerifyPassword.setText(null);
		textCompanyName.setText(null);
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signup_Screen window = new Signup_Screen();
					window.frmSignup.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Signup_Screen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSignup = new JFrame();
		frmSignup.getContentPane().setBackground(Color.WHITE);
		frmSignup.setTitle("Signup");
		frmSignup.setBounds(500, 500, 655, 494);
		frmSignup.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSignup.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(193, 13, 56, 16);
		frmSignup.getContentPane().add(label);
		
		textUsername = new JTextField();
		textUsername.setBounds(285, 183, 189, 29);
		frmSignup.getContentPane().add(textUsername);
		textUsername.setColumns(10);
		
		textNewPassword = new JPasswordField();
		textNewPassword.setBounds(285, 251, 189, 29);
		frmSignup.getContentPane().add(textNewPassword);
		
		textVerifyPassword = new JPasswordField();
		textVerifyPassword.setBounds(285, 320, 189, 29);
		frmSignup.getContentPane().add(textVerifyPassword);
		
		textCompanyName = new JTextField();
		textCompanyName.setBounds(285, 113, 189, 29);
		frmSignup.getContentPane().add(textCompanyName);
		textCompanyName.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Already have an account?");
		lblNewLabel.setFont(new Font("Sitka Small", Font.PLAIN, 14));
		lblNewLabel.setBounds(347, 418, 189, 16);
		frmSignup.getContentPane().add(lblNewLabel);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(23, 309, 436, -7);
		frmSignup.getContentPane().add(separator_1);
		
		JLabel lblCompanyName = new JLabel("Company name");
		lblCompanyName.setFont(new Font("Sitka Small", Font.BOLD, 17));
		lblCompanyName.setBounds(285, 86, 189, 31);
		frmSignup.getContentPane().add(lblCompanyName);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Sitka Small", Font.BOLD, 17));
		lblUsername.setBounds(285, 155, 137, 29);
		frmSignup.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Sitka Small", Font.BOLD, 17));
		lblPassword.setBounds(285, 225, 175, 26);
		frmSignup.getContentPane().add(lblPassword);
		
		JLabel lblVerifyPassword = new JLabel("Verify password\r\n");
		lblVerifyPassword.setFont(new Font("Sitka Small", Font.BOLD, 17));
		lblVerifyPassword.setBounds(285, 297, 189, 20);
		frmSignup.getContentPane().add(lblVerifyPassword);
		
		Button button = new Button("Signup");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Sitka Small", Font.PLAIN, 12));
		button.setBackground(new Color(0, 0, 128));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String	username = textUsername.getText();
				String	password = textNewPassword.getText();
				String	company = textCompanyName.getText();
				String  verifyPassword = textVerifyPassword.getText();
	    		if(username.isEmpty() || password.isEmpty() || company.isEmpty() || verifyPassword.isEmpty())
	    		{
	    			JOptionPane.showMessageDialog(null,"Do not leave any field empty.","Login Error",JOptionPane.ERROR_MESSAGE);
	    		}
	    		else
				{
	    			String  request = "Signup/"+username+"/"+password+"/"+verifyPassword+"/"+company+"/";
	    			Client.send_data_to_server(request);	
				}
			}
		});
		button.setBounds(285, 355, 189, 34);
		frmSignup.getContentPane().add(button);
		
		JLabel lblSignup = new JLabel("SIGNUP");
		lblSignup.setFont(new Font("Sitka Small", Font.BOLD, 22));
		lblSignup.setBounds(383, 13, 175, 53);
		frmSignup.getContentPane().add(lblSignup);
		
		Button button_1 = new Button("Login");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login_System info = new Login_System();
				Login_System.main(null);
				frmSignup.dispose();
			}
		});
		button_1.setForeground(new Color(255, 255, 255));
		button_1.setBackground(new Color(0, 0, 128));
		button_1.setBounds(531, 412, 79, 24);
		frmSignup.getContentPane().add(button_1);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(Signup_Screen.class.getResource("/images/resize2.jpg")));
		lblNewLabel_1.setBounds(12, -20, 251, 474);
		frmSignup.getContentPane().add(lblNewLabel_1);
	}
}
